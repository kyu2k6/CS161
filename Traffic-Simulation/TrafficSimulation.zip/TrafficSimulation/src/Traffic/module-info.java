module TrafficSimulation {
	requires java.desktop;
}